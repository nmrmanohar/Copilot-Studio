# Healthcare Patient-Care Coordination Copilot

This package contains sample data and environment setup scripts for the Healthcare Patient-Care Coordination Copilot solution described in the case study.
